##
# An anonymous class like:
#
#   c = Class.new do end
#
# AnonClass is currently not used.

class RDoc::AnonClass < RDoc::ClassModule
end

